﻿// ID: K8174
// Program 1.
// due 9/24/2019.
// CIS 199-2
// This program is used to estimate the number of gallon of paint.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Program_1
{
    class Program
    {
        static void Main(string[] args)
        {
            double lenght, //variable to store the lenght.
                height, //variable to store the height.
                minGallons, //variable to store the minimum of gallons.
                gallonsToBuy; // variable to store the number of gallons to buy.

            int NumberOfDoors,
                NumberOfWindows,
                coats;

            const int doors = 21, // total of square feet of each door.
                    windows = 12, // total of square feet of each window.
                    canCoverage = 400;  // Each can of paint can cover about 400 square feet.
            Write("Welcome to the Handy-Dandy Paint Estimator");

            Write("Enter the total Lenght of wallls (In feet): ");
            lenght = double.Parse(ReadLine());

            Write("Enter the total height of wallls (In feet): ");
            height = double.Parse(ReadLine());

            Write("Enter the number of doors (non-neg int) : ");
            NumberOfDoors= int.Parse(ReadLine());

            Write("Enter the number of windows (non-neg int): ");
            NumberOfWindows = int.Parse(ReadLine());

            Write("Enter the number of paint coats (non-neg int): ");
            coats = int.Parse(ReadLine()); 

            minGallons = ((((lenght * height) - NumberOfDoors * doors) - NumberOfWindows * windows) * coats) / canCoverage; // the equation that is used for the calculation
            WriteLine($"You need a minimum of {minGallons:f1} gallons of paint");

            gallonsToBuy = (int)Math.Ceiling(minGallons); // used to round up the number of gallons.
            WriteLine($"You will need to buy {gallonsToBuy} gallons,though");


         }
    }
}
