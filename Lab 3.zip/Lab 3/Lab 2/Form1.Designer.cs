﻿namespace Lab_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.radiusofsphere = new System.Windows.Forms.Label();
            this.radius_input = new System.Windows.Forms.TextBox();
            this.diam = new System.Windows.Forms.Label();
            this.lbl_diameter = new System.Windows.Forms.Label();
            this.sureface = new System.Windows.Forms.Label();
            this.lbl_sureface = new System.Windows.Forms.Label();
            this.volu = new System.Windows.Forms.Label();
            this.lbl_volume = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Calculate_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // radiusofsphere
            // 
            this.radiusofsphere.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.radiusofsphere.Location = new System.Drawing.Point(408, 103);
            this.radiusofsphere.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.radiusofsphere.Name = "radiusofsphere";
            this.radiusofsphere.Size = new System.Drawing.Size(214, 53);
            this.radiusofsphere.TabIndex = 0;
            this.radiusofsphere.Text = "Radius of sphere";
            // 
            // radius_input
            // 
            this.radius_input.Location = new System.Drawing.Point(639, 114);
            this.radius_input.Margin = new System.Windows.Forms.Padding(7);
            this.radius_input.Name = "radius_input";
            this.radius_input.Size = new System.Drawing.Size(228, 35);
            this.radius_input.TabIndex = 1;
            // 
            // diam
            // 
            this.diam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.diam.Location = new System.Drawing.Point(28, 404);
            this.diam.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.diam.Name = "diam";
            this.diam.Size = new System.Drawing.Size(172, 53);
            this.diam.TabIndex = 2;
            this.diam.Text = "Diameter";
            // 
            // lbl_diameter
            // 
            this.lbl_diameter.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_diameter.Location = new System.Drawing.Point(217, 404);
            this.lbl_diameter.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbl_diameter.Name = "lbl_diameter";
            this.lbl_diameter.Size = new System.Drawing.Size(172, 53);
            this.lbl_diameter.TabIndex = 3;
            // 
            // sureface
            // 
            this.sureface.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sureface.Location = new System.Drawing.Point(28, 522);
            this.sureface.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.sureface.Name = "sureface";
            this.sureface.Size = new System.Drawing.Size(172, 53);
            this.sureface.TabIndex = 4;
            this.sureface.Text = "Surface Area";
            // 
            // lbl_sureface
            // 
            this.lbl_sureface.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_sureface.Location = new System.Drawing.Point(217, 522);
            this.lbl_sureface.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbl_sureface.Name = "lbl_sureface";
            this.lbl_sureface.Size = new System.Drawing.Size(172, 53);
            this.lbl_sureface.TabIndex = 5;
            // 
            // volu
            // 
            this.volu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.volu.Location = new System.Drawing.Point(28, 634);
            this.volu.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.volu.Name = "volu";
            this.volu.Size = new System.Drawing.Size(172, 53);
            this.volu.TabIndex = 6;
            this.volu.Text = "Volume";
            // 
            // lbl_volume
            // 
            this.lbl_volume.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_volume.Location = new System.Drawing.Point(217, 634);
            this.lbl_volume.Margin = new System.Windows.Forms.Padding(7, 0, 7, 0);
            this.lbl_volume.Name = "lbl_volume";
            this.lbl_volume.Size = new System.Drawing.Size(172, 53);
            this.lbl_volume.TabIndex = 7;
            this.lbl_volume.Click += new System.EventHandler(this.Label7_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(28, 27);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(350, 335);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(488, 404);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(350, 335);
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // Calculate_button
            // 
            this.Calculate_button.Location = new System.Drawing.Point(541, 210);
            this.Calculate_button.Name = "Calculate_button";
            this.Calculate_button.Size = new System.Drawing.Size(192, 60);
            this.Calculate_button.TabIndex = 10;
            this.Calculate_button.Text = "Calculate";
            this.Calculate_button.UseVisualStyleBackColor = true;
            this.Calculate_button.Click += new System.EventHandler(this.Calculate_button_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.Calculate_button;
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 805);
            this.Controls.Add(this.Calculate_button);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lbl_volume);
            this.Controls.Add(this.volu);
            this.Controls.Add(this.lbl_sureface);
            this.Controls.Add(this.sureface);
            this.Controls.Add(this.lbl_diameter);
            this.Controls.Add(this.diam);
            this.Controls.Add(this.radius_input);
            this.Controls.Add(this.radiusofsphere);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Lab3";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label radiusofsphere;
        private System.Windows.Forms.TextBox radius_input;
        private System.Windows.Forms.Label diam;
        private System.Windows.Forms.Label lbl_diameter;
        private System.Windows.Forms.Label sureface;
        private System.Windows.Forms.Label lbl_sureface;
        private System.Windows.Forms.Label volu;
        private System.Windows.Forms.Label lbl_volume;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button Calculate_button;
    }
}

