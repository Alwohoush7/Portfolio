﻿// ID: K8174.
// Lab number 3.
// due 9/22/2019.
// CIS 199-2
// this program is used to calculates the all the different measurements for a sphere.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label7_Click(object sender, EventArgs e)
        {

        }
        // The calculation button to determine the diameter, sureface area and the volume of the sphere.
        private void Calculate_button_Click(object sender, EventArgs e)
        {
            double radius;
            radius = double.Parse(radius_input.Text);

            double Diameter, //Diameter of the sphere
                surface_area, //sureface of the sphere
                volume; // volume of the sphere


            Diameter = radius * 2; //Diameter equation.
            surface_area = 4 * Math.PI * Math.Pow(radius, 2); //The equation for the sureface area
            volume = (4* Math.PI * Math.Pow(radius, 3))/3; //The equation for the volume



            lbl_diameter.Text = $"{Diameter:f2}"; //diameter output
            lbl_sureface.Text = $"{surface_area:f2}"; //sureface area output
            lbl_volume.Text = $"{volume:f2}"; // volume output



        }
    }
}
