﻿// ID: K8174
// Lab number 2.
// due 9/15/2019.
// CIS 199-2
// this program calculates the different ratio for a tip after entering the value of a meal.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2_GUI_app
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // The tip calculation button/clicker
        private void Calc_tip_Click(object sender, EventArgs e) 
        {

            double price; // The price of a meal
            price = double.Parse(price_input.Text);

            double  tip_L = .15, // a 15% tip calculator.
                    tip_M = .18, // a 18% tip calculator.
                    tip_H = .20; // a 20% tip calculator.

            double  tip15, // used to calculate the 15% tip.
                    tip18, // used to calculate the 18% tip.
                    tip20; // used to calculate the 20% tip.


            tip15 = price * tip_L;
            tip18 = price * tip_M;
            tip20 = price * tip_H;

        
            lbl15tip.Text = $"{tip15:c}";
            lbl18tip.Text = $"{tip18:c}";
            lbl20tip.Text = $"{tip20:c}";



        }
    }

    
 }
