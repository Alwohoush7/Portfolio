﻿namespace Lab_2_GUI_app
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblprice = new System.Windows.Forms.Label();
            this.price_input = new System.Windows.Forms.TextBox();
            this.lbl_low = new System.Windows.Forms.Label();
            this.lbl15tip = new System.Windows.Forms.Label();
            this.lbl_medium = new System.Windows.Forms.Label();
            this.lbl18tip = new System.Windows.Forms.Label();
            this.lbl_high = new System.Windows.Forms.Label();
            this.lbl20tip = new System.Windows.Forms.Label();
            this.calc_tip = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblprice
            // 
            this.lblprice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblprice.Location = new System.Drawing.Point(71, 65);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(208, 52);
            this.lblprice.TabIndex = 0;
            this.lblprice.Text = "Enter price of meal";
            // 
            // price_input
            // 
            this.price_input.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.price_input.Location = new System.Drawing.Point(358, 82);
            this.price_input.Name = "price_input";
            this.price_input.Size = new System.Drawing.Size(213, 35);
            this.price_input.TabIndex = 1;
            // 
            // lbl_low
            // 
            this.lbl_low.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_low.Location = new System.Drawing.Point(70, 143);
            this.lbl_low.Name = "lbl_low";
            this.lbl_low.Size = new System.Drawing.Size(208, 52);
            this.lbl_low.TabIndex = 2;
            this.lbl_low.Text = "Low_tip";
            // 
            // lbl15tip
            // 
            this.lbl15tip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl15tip.Location = new System.Drawing.Point(363, 143);
            this.lbl15tip.Name = "lbl15tip";
            this.lbl15tip.Size = new System.Drawing.Size(208, 52);
            this.lbl15tip.TabIndex = 3;
            // 
            // lbl_medium
            // 
            this.lbl_medium.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_medium.Location = new System.Drawing.Point(71, 228);
            this.lbl_medium.Name = "lbl_medium";
            this.lbl_medium.Size = new System.Drawing.Size(208, 52);
            this.lbl_medium.TabIndex = 4;
            this.lbl_medium.Text = "Medium_tip";
            // 
            // lbl18tip
            // 
            this.lbl18tip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl18tip.Location = new System.Drawing.Point(363, 228);
            this.lbl18tip.Name = "lbl18tip";
            this.lbl18tip.Size = new System.Drawing.Size(208, 52);
            this.lbl18tip.TabIndex = 5;
            // 
            // lbl_high
            // 
            this.lbl_high.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_high.Location = new System.Drawing.Point(71, 310);
            this.lbl_high.Name = "lbl_high";
            this.lbl_high.Size = new System.Drawing.Size(208, 52);
            this.lbl_high.TabIndex = 6;
            this.lbl_high.Text = "High_tip";
            // 
            // lbl20tip
            // 
            this.lbl20tip.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl20tip.Location = new System.Drawing.Point(363, 310);
            this.lbl20tip.Name = "lbl20tip";
            this.lbl20tip.Size = new System.Drawing.Size(208, 52);
            this.lbl20tip.TabIndex = 7;
            // 
            // calc_tip
            // 
            this.calc_tip.Location = new System.Drawing.Point(172, 421);
            this.calc_tip.Name = "calc_tip";
            this.calc_tip.Size = new System.Drawing.Size(300, 58);
            this.calc_tip.TabIndex = 8;
            this.calc_tip.Text = "Calculate Tip ";
            this.calc_tip.UseVisualStyleBackColor = true;
            this.calc_tip.Click += new System.EventHandler(this.Calc_tip_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(768, 547);
            this.Controls.Add(this.calc_tip);
            this.Controls.Add(this.lbl20tip);
            this.Controls.Add(this.lbl_high);
            this.Controls.Add(this.lbl18tip);
            this.Controls.Add(this.lbl_medium);
            this.Controls.Add(this.lbl15tip);
            this.Controls.Add(this.lbl_low);
            this.Controls.Add(this.price_input);
            this.Controls.Add(this.lblprice);
            this.Name = "Form1";
            this.Text = "Lab2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.TextBox price_input;
        private System.Windows.Forms.Label lbl_low;
        private System.Windows.Forms.Label lbl15tip;
        private System.Windows.Forms.Label lbl_medium;
        private System.Windows.Forms.Label lbl18tip;
        private System.Windows.Forms.Label lbl_high;
        private System.Windows.Forms.Label lbl20tip;
        private System.Windows.Forms.Button calc_tip;
    }
}

