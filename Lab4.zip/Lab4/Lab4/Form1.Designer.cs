﻿namespace Lab4
{
    partial class Lab4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grade_input = new System.Windows.Forms.Label();
            this.score_input = new System.Windows.Forms.Label();
            this.decisionlbl = new System.Windows.Forms.Label();
            this.accept_lbl = new System.Windows.Forms.Label();
            this.acpt_count = new System.Windows.Forms.Label();
            this.reject_lbl = new System.Windows.Forms.Label();
            this.rjct_count = new System.Windows.Forms.Label();
            this.decision_output = new System.Windows.Forms.Label();
            this.gradetxt = new System.Windows.Forms.TextBox();
            this.scoretxt = new System.Windows.Forms.TextBox();
            this.Admit_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // grade_input
            // 
            this.grade_input.Location = new System.Drawing.Point(68, 97);
            this.grade_input.Name = "grade_input";
            this.grade_input.Size = new System.Drawing.Size(383, 65);
            this.grade_input.TabIndex = 0;
            this.grade_input.Text = "Enter grade point average:";
            // 
            // score_input
            // 
            this.score_input.Location = new System.Drawing.Point(68, 168);
            this.score_input.Name = "score_input";
            this.score_input.Size = new System.Drawing.Size(388, 65);
            this.score_input.TabIndex = 1;
            this.score_input.Text = "Enter admission test score:";
            // 
            // decisionlbl
            // 
            this.decisionlbl.Location = new System.Drawing.Point(68, 247);
            this.decisionlbl.Name = "decisionlbl";
            this.decisionlbl.Size = new System.Drawing.Size(317, 65);
            this.decisionlbl.TabIndex = 2;
            this.decisionlbl.Text = "Admission Decision:";
            
            // 
            // accept_lbl
            // 
            this.accept_lbl.Location = new System.Drawing.Point(68, 507);
            this.accept_lbl.Name = "accept_lbl";
            this.accept_lbl.Size = new System.Drawing.Size(200, 45);
            this.accept_lbl.TabIndex = 3;
            this.accept_lbl.Text = "Accepted";
            // 
            // acpt_count
            // 
            this.acpt_count.Location = new System.Drawing.Point(200, 507);
            this.acpt_count.Name = "acpt_count";
            this.acpt_count.Size = new System.Drawing.Size(165, 45);
            this.acpt_count.TabIndex = 4;
            this.acpt_count.Text = "0";
            // 
            // reject_lbl
            // 
            this.reject_lbl.Location = new System.Drawing.Point(68, 576);
            this.reject_lbl.Name = "reject_lbl";
            this.reject_lbl.Size = new System.Drawing.Size(196, 45);
            this.reject_lbl.TabIndex = 5;
            this.reject_lbl.Text = "Rejected";
            // 
            // rjct_count
            // 
            this.rjct_count.Location = new System.Drawing.Point(200, 576);
            this.rjct_count.Name = "rjct_count";
            this.rjct_count.Size = new System.Drawing.Size(165, 45);
            this.rjct_count.TabIndex = 6;
            this.rjct_count.Text = "0";
            // 
            // decision_output
            // 
            this.decision_output.Location = new System.Drawing.Point(551, 272);
            this.decision_output.Name = "decision_output";
            this.decision_output.Size = new System.Drawing.Size(175, 59);
            this.decision_output.TabIndex = 7;
            // 
            // gradetxt
            // 
            this.gradetxt.Location = new System.Drawing.Point(550, 97);
            this.gradetxt.Name = "gradetxt";
            this.gradetxt.Size = new System.Drawing.Size(165, 35);
            this.gradetxt.TabIndex = 8;
            // 
            // scoretxt
            // 
            this.scoretxt.Location = new System.Drawing.Point(556, 179);
            this.scoretxt.Name = "scoretxt";
            this.scoretxt.Size = new System.Drawing.Size(159, 35);
            this.scoretxt.TabIndex = 9;
            // 
            // Admit_btn
            // 
            this.Admit_btn.Location = new System.Drawing.Point(418, 381);
            this.Admit_btn.Name = "Admit_btn";
            this.Admit_btn.Size = new System.Drawing.Size(213, 82);
            this.Admit_btn.TabIndex = 10;
            this.Admit_btn.Text = "Admit";
            this.Admit_btn.UseVisualStyleBackColor = true;
            this.Admit_btn.Click += new System.EventHandler(this.Admit_btn_Click);
            // 
            // Lab4
            // 
            this.AcceptButton = this.Admit_btn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 666);
            this.Controls.Add(this.Admit_btn);
            this.Controls.Add(this.scoretxt);
            this.Controls.Add(this.gradetxt);
            this.Controls.Add(this.decision_output);
            this.Controls.Add(this.rjct_count);
            this.Controls.Add(this.reject_lbl);
            this.Controls.Add(this.acpt_count);
            this.Controls.Add(this.accept_lbl);
            this.Controls.Add(this.decisionlbl);
            this.Controls.Add(this.score_input);
            this.Controls.Add(this.grade_input);
            this.Name = "Lab4";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label grade_input;
        private System.Windows.Forms.Label score_input;
        private System.Windows.Forms.Label decisionlbl;
        private System.Windows.Forms.Label accept_lbl;
        private System.Windows.Forms.Label acpt_count;
        private System.Windows.Forms.Label reject_lbl;
        private System.Windows.Forms.Label rjct_count;
        private System.Windows.Forms.Label decision_output;
        private System.Windows.Forms.TextBox gradetxt;
        private System.Windows.Forms.TextBox scoretxt;
        private System.Windows.Forms.Button Admit_btn;
    }
}

