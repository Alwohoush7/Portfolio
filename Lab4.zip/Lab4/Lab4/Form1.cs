﻿// ID: K8174
// Lab number 4.
// due 9/28/2019.
// CIS 199-2
// This program uses students' grade points average and total test scores to determine their admission at the university
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Lab4 : Form
    {
        public Lab4()
        {
            InitializeComponent();
        }
        int counteracc, // number of accepted students.
            counterreg; // number of rejected students.

        

        private void Admit_btn_Click(object sender, EventArgs e) // the button what will be used to see if studnets get admitted or rejects.
        {
            double grade=0, // grades varialble.
                score=0; // scores varialble.
            String Accepted = "Accepted", Rejected = "Rejected";


            if (double.TryParse(gradetxt.Text, out grade) )   { }
            else
            {
                MessageBox.Show("Enter a valid GPA"); //error message if not a valid GPA has been entered (if letters).
            }
            if (grade < 0.0) {
                MessageBox.Show("Enter a valid GPA"); //error message if not a valid GPA has been entered (if negative numbers).
            }
            if (double.TryParse(scoretxt.Text, out score) ) { }
            else
            {
                MessageBox.Show("Enter a valid test score"); //error message if not a valid test score has been entered (if letters).
            }

            if (score < 0.0) {
                MessageBox.Show("Enter a valid test score"); //error message if not a valid test score has been entered (if negative numbers).
            }

            if (grade >= 3.0 && score >= 60) //first admission test.
            {                                // Students need to earn at least a 3.0 GPA and at least 60 on test scores.
                decision_output.Text = $"{Accepted}";
                counteracc++;
                acpt_count.Text = $"{counteracc}"; //Accept counter.
            }
                               
            else if (grade < 3.0 && score >= 80) //second admission test.
            {                                    // if students get a lower GPA but more than 80 on test score will still be accpeted.
                decision_output.Text = $"{Accepted}";
                counteracc++;
                acpt_count.Text = $"{counteracc}"; //Acceptness counter.
            }
            else if (grade>0.0 && score>0.0) // third admission test.
            {                                // students who don't meet the first two admisson test will be rejected.
                decision_output.Text = $"{Rejected}";
                counterreg++;
                rjct_count.Text = $"{counterreg}"; //reject counter.
            }
        }
        

    }
}
