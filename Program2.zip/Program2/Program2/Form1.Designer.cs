﻿namespace Program2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name_lbl = new System.Windows.Forms.Label();
            this.hours_lbl = new System.Windows.Forms.Label();
            this.name_txt = new System.Windows.Forms.TextBox();
            this.hours_txt = new System.Windows.Forms.TextBox();
            this.Check_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // name_lbl
            // 
            this.name_lbl.Location = new System.Drawing.Point(111, 104);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(282, 53);
            this.name_lbl.TabIndex = 0;
            this.name_lbl.Text = "First letter of last name";
            // 
            // hours_lbl
            // 
            this.hours_lbl.Location = new System.Drawing.Point(111, 197);
            this.hours_lbl.Name = "hours_lbl";
            this.hours_lbl.Size = new System.Drawing.Size(282, 59);
            this.hours_lbl.TabIndex = 1;
            this.hours_lbl.Text = "Credit hours";
            // 
            // name_txt
            // 
            this.name_txt.Location = new System.Drawing.Point(475, 104);
            this.name_txt.Name = "name_txt";
            this.name_txt.Size = new System.Drawing.Size(100, 35);
            this.name_txt.TabIndex = 2;
            // 
            // hours_txt
            // 
            this.hours_txt.Location = new System.Drawing.Point(475, 197);
            this.hours_txt.Name = "hours_txt";
            this.hours_txt.Size = new System.Drawing.Size(100, 35);
            this.hours_txt.TabIndex = 3;
            // 
            // Check_button
            // 
            this.Check_button.Location = new System.Drawing.Point(279, 340);
            this.Check_button.Name = "Check_button";
            this.Check_button.Size = new System.Drawing.Size(196, 68);
            this.Check_button.TabIndex = 4;
            this.Check_button.Text = "Check";
            this.Check_button.UseVisualStyleBackColor = true;
            this.Check_button.Click += new System.EventHandler(this.Check_button_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.Check_button;
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 549);
            this.Controls.Add(this.Check_button);
            this.Controls.Add(this.hours_txt);
            this.Controls.Add(this.name_txt);
            this.Controls.Add(this.hours_lbl);
            this.Controls.Add(this.name_lbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.Label hours_lbl;
        private System.Windows.Forms.TextBox name_txt;
        private System.Windows.Forms.TextBox hours_txt;
        private System.Windows.Forms.Button Check_button;
    }
}

