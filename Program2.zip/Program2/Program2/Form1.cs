﻿// ID: K8174.
// Program 2.
// due 10/16/2019.
// CIS 199-2
// this program is used to use students credit hours and their first letter of last name to determine when can they register for next semester's classes.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // The check button for registration.
        private void Check_button_Click(object sender, EventArgs e)
        {
            int hours; //number of credit hours earned.
            char fst_letr; //The first letter of last name.
            const string time1 = "8:30 AM"; // first availabile time.
            const string time2 = "10:00 AM"; // second availabile time.
            const string time3 = "11:30 AM"; // Third availabile time.
            const string time4 = "2:00 PM"; // Forth availabile time.
            const string time5 = "4:00 PM"; // Fifth availabile time.

            const string day1 = "MONDAY, NOV. 4 "; // first availabile day.
            const string day2 = "TUESDAY, NOV. 5 "; // second availabile day.
            const string day3 = "WEDNESDAY, NOV. 6"; // Third availabile day.
            const string day4 = "THURSDAY, NOV. 7"; // Forth availabile day.
            const string day5 = "FRIDAY, NOV. 8"; // Fifth availabile time.
            const string day6 = "MONDAY, NOV. 11"; // Sixth availabile time.

            const int SENIORS = 90,  // A studnet is called a senior if at least 90 hours earned.
                JUNIORS = 60, // A studnet is called a junior if at least 60 hours earned.
                SOPHOMORES = 30, // A studnet is called a sophmore if at least 30 hours earned.
                GRADUATE = 120; // A studnet is called a graduate if more than 90 hours earned.

            hours = int.Parse(hours_txt.Text); // number of hours from form's hour's textbox.
            fst_letr = char.Parse(name_txt.Text); // first letter of last name from form's name's textbox.

            if (char.IsLetter(fst_letr)) // used to make sure a letter is entered in the name textbox.
            {
                fst_letr = char.ToUpper(fst_letr); // used to capitalize if a small case letter entered.

                if (hours >= JUNIORS && hours <= GRADUATE)
                {

                    if (fst_letr <= 'D')
                    
                        if (hours >= SENIORS)
                            MessageBox.Show($"{day1} AT {time3}"); 
                        else
                            MessageBox.Show($"{day2} AT {time3}");

                    else if (fst_letr <= 'I' )
                    
                        if (hours >= SENIORS)
                            MessageBox.Show($"{day1} AT {time4}");
                        else
                            MessageBox.Show($"{day2} AT {time4}");
                
                    else if (fst_letr <= 'O')
                    
                        if (hours >= SENIORS)
                            MessageBox.Show($"{day1} AT {time5}");
                        else
                            MessageBox.Show($"{day2} AT {time5}");

                    else if (fst_letr <= 'S')
                    
                        if (hours >= SENIORS)
                            MessageBox.Show($"{day1} AT {time1}");
                        else
                            MessageBox.Show($"{day2} AT {time1}");                   
                    else
                    {
                        if (hours >= SENIORS)
                            MessageBox.Show($"{day1} AT {time2}");
                        else
                            MessageBox.Show($"{day2} AT {time2}");
                    }

                }
                else
                {
                    if(fst_letr <= 'B')
                        if(hours>= SOPHOMORES)
                            MessageBox.Show($"{day3} AT {time5}");
                    else
                            MessageBox.Show($"{day5} AT {time5}");
                    else if (fst_letr <= 'D')
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day4} AT {time1}");
                        else
                            MessageBox.Show($"{day6} AT {time1}");
                    else if (fst_letr <= 'F')
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day4} AT {time2}");
                        else
                            MessageBox.Show($"{day6} AT {time2}");
                    else if(fst_letr<='I')
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day4} AT {time3}");
                        else
                            MessageBox.Show($"{day6} AT {time3}");
                    else if(fst_letr<='L')
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day4} AT {time4}");
                        else
                            MessageBox.Show($"{day6} AT {time4}");
                    else if (fst_letr<='O')
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day4} AT {time5}");
                        else
                            MessageBox.Show($"{day6} AT {time5}");
                    else if (fst_letr<='Q')
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day3} AT {time1}");
                        else
                            MessageBox.Show($"{day5} AT {time1}");
                    else if (fst_letr<='S')
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day3} AT {time2}");
                        else
                            MessageBox.Show($"{day5} AT {time2}");
                    else if (fst_letr<='V')
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day3} AT {time3}");
                        else
                            MessageBox.Show($"{day5} AT {time3}");
                    else
                    {
                        if (hours >= SOPHOMORES)
                            MessageBox.Show($"{day3} AT {time4}");
                        else
                            MessageBox.Show($"{day5} AT {time4}");
                    }

                }

            }

        }
    }
}
